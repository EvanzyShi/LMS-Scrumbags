const BACKEND_PORT = 5005;
export const BASE_URL = 'http://localhost:' + BACKEND_PORT;
