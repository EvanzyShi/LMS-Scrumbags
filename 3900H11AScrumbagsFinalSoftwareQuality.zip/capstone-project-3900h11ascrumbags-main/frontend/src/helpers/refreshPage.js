const refreshPage = () => {
  window.location.reload();
};

export default refreshPage;